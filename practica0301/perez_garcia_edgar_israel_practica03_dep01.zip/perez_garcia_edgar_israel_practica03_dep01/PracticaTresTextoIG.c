#include <stdio.h>

int main(int argc, char *argv[]) {
    
   printf("****************************************************\n");
    printf("\t \" IIIIIIIIIIIIIII  GGGGGGG    !! \"\n");
    printf("\t \"       III       G        G  !! \"\n");
    printf("\t \"       III      G          G !! \"\n");
    printf("\t \"       III     G             !! \"\n");
    printf("\t \"       III     G             !! \"\n");
    printf("\t \"       III     G        GGGG !! \"\n");
    printf("\t \"       III      G          G !! \"\n");
    printf("\t \"       III       G        G  !! \"\n");
    printf("\t \" IIIIIIIIIIIIIII  GGGGGGGG   oo \"\n");
    printf("****************************************************\n\n");
    printf("La programacion es algo genial !!!"); 

    return 0;
}